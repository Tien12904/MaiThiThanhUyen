import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../model/Note.dart';

class NoteDatabaseHelper {
  static const _databaseName = "NotesDatabase.db";
  static const _databaseVersion = 1;
  static const table = 'notes';

  static const columnId = 'id';
  static const columnTitle = 'title';
  static const columnContent = 'content';
  static const columnPriority = 'priority';
  static const columnCreatedAt = 'createdAt';
  static const columnModifiedAt = 'modifiedAt';
  static const columnTags = 'tags';
  static const columnColor = 'color';

  // Make this a singleton class.
  NoteDatabaseHelper._privateConstructor();
  static final NoteDatabaseHelper instance = NoteDatabaseHelper._privateConstructor();

  // Only have a single app-wide reference to the database.
  static Database? _database;
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  // Opens the database and creates it if it doesn't exist.
  _initDatabase() async {
    String path = join(await getDatabasesPath(), _databaseName);
    return await openDatabase(path,
        version: _databaseVersion,
        onCreate: _onCreate);
  }

  // SQL code to create the database table.
  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE table (
        Id INTEGER PRIMARY KEY AUTOINCREMENT,
        Title TEXT NOT NULL,
        Content TEXT NOT NULL,
        Priority INTEGER NOT NULL,
        CreatedAt TEXT NOT NULL,
        ModifiedAt TEXT NOT NULL,
        Tags TEXT,
        Color TEXT
      )
    ''');
    await _insertSampleData(db);
  }
  Future _insertSampleData(Database db) async {
    // Danh sách dữ liệu mẫu
    final List<Map<String, dynamic>> sampleNote = [
      {
        'title':'Ghi nhớ mật khẩu mới',
        'Content':'Mật khẩu mới cho tài khoản ngân hàng là ABC@123.',
        'priority':2,
        'CreatedAt':'2025-04-11 18:00:00',
        'modifiedAt':'2025-04-11 18:00:00',
        'color':'#F44336'
      },

    ];

    // Chèn từng người dùng vào cơ sở dữ liệu
    for (final NoteData in sampleNote) {
      await db.insert('users', NoteData);
    }
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }

  // Helper methods

  // Inserts a row in the database where each key in the Map is a column name
  // and the value is the column value. The return value is the id of the
  // last inserted row.
  Future<int> insertNote(Note note) async {
    Database db = await instance.database;
    return await db.insert('table', note.toMap());
  }

  // All of the rows are returned as a list of maps, where each map is
  // a key-value list of columns.
  Future<List<Note>> getAllNotes() async {
    Database db = await instance.database;
    final List<Map<String, dynamic>> maps = await db.query(table);
    return List.generate(maps.length, (i) {
      return Note.fromMap(maps[i]);
    });
  }

  // Given the id, return the row as a map.
  Future<Note?> getNoteById(int id) async {
    Database db = await instance.database;
    List<Map<String, dynamic>> results = await db.query(
      table,
      where: '$columnId = ?',
      whereArgs: [id],
    );
    if (results.isNotEmpty) {
      return Note.fromMap(results.first);
    }
    return null;
  }

  // Updates the row in the database where the id specified as the key.
  // The number of affected rows is returned. This should be 1 unless something
  // went wrong.
  Future<int> updateNote(Note note) async {
    Database db = await instance.database;
    return await db.update(
      table,
      note.toMap(),
      where: '$columnId = ?',
      whereArgs: [note.id],
    );
  }

  // Deletes the row specified by the id. The number of affected rows returned
  // should be 1 unless there was a problem.
  Future<int> deleteNote(int id) async {
    Database db = await instance.database;
    return await db.delete(
      table,
      where: '$columnId = ?',
      whereArgs: [id],
    );
  }

  Future<List<Note>> getNotesByPriority(int priority) async {
    Database db = await instance.database;
    final List<Map<String, dynamic>> maps = await db.query(
      table,
      where: '$columnPriority = ?',
      whereArgs: [priority],
    );
    return List.generate(maps.length, (i) {
      return Note.fromMap(maps[i]);
    });
  }

  Future<List<Note>> searchNotes(String query) async {
    Database db = await instance.database;
    final List<Map<String, dynamic>> maps = await db.query(
      table,
      where: '$columnTitle LIKE ? OR $columnContent LIKE ? OR $columnTags LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
    );
    return List.generate(maps.length, (i) {
      return Note.fromMap(maps[i]);
    });
  }
}