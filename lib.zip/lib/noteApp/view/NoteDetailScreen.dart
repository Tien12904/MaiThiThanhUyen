import 'package:flutter/material.dart';
import '../model/Note.dart';
import 'package:intl/intl.dart';
import 'NoteFormScreen.dart';

class NoteDetailScreen extends StatelessWidget {
  final Note note;

  NoteDetailScreen({required this.note});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(note.title),
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => NoteForm(note: note)),
              );
              if (result != null && result is Note) {
                // You might want to update the displayed note here if needed
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Ghi chú đã được cập nhật.')),
                );
              }
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              note.title,
              style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16.0),
            Row(
              children: [
                Text('Ưu tiên: ${note.priority}'),
                SizedBox(width: 16.0),
                _getPriorityIndicator(note.priority),
              ],
            ),
            SizedBox(height: 8.0),
            Text('Ngày tạo: ${DateFormat('dd/MM/yyyy HH:mm:ss').format(note.createdAt.toLocal())}',
                style: TextStyle(color: Colors.grey)),
            SizedBox(height: 8.0),
            Text('Ngày sửa đổi: ${DateFormat('dd/MM/yyyy HH:mm:ss').format(note.modifiedAt.toLocal())}',
                style: TextStyle(color: Colors.grey)),
            SizedBox(height: 16.0),
            Text(
              note.content,
              style: TextStyle(fontSize: 16.0),
            ),
            if (note.tags != null && note.tags!.isNotEmpty) ...[
              SizedBox(height: 16.0),
              Wrap(
                spacing: 8.0,
                children: note.tags!.map((tag) => Chip(label: Text(tag))).toList(),
              ),
            ],
            if (note.color != null) ...[
              SizedBox(height: 16.0),
              Text('Màu sắc:', style: TextStyle(fontWeight: FontWeight.bold)),
              Container(
                width: 50.0,
                height: 50.0,
                color: _getColorFromHex(note.color!),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _getPriorityIndicator(int priority) {
    Color color;
    switch (priority) {
      case 1:
        color = Colors.green;
        break;
      case 2:
        color = Colors.yellow;
        break;
      case 3:
        color = Colors.red;
        break;
      default:
        color = Colors.grey;
    }
    return Container(
      width: 15.0,
      height: 15.0,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
      ),
    );
  }

  Color? _getColorFromHex(String hexColor) {
    final hex = hexColor.replaceAll('#', '');
    if (hex.length == 6) {
      return Color(int.parse('FF$hex', radix: 16));
    } else if (hex.length == 8) {
      return Color(int.parse(hex, radix: 16));
    }
    return null;
  }
}