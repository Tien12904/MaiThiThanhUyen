import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:app_02/noteApp/model/Note.dart';

class NoteForm extends StatefulWidget {
final Note? note;

 NoteForm({this.note});

  @override
  _NoteFormState createState() => _NoteFormState();
}

class _NoteFormState extends State<NoteForm> {
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();
  int _priority = 1;
  List<String> _tags = [];
  String? _color;
  final _tagController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.note != null) {
      _titleController.text = widget.note!.title;
      _contentController.text = widget.note!.content;
      _priority = widget.note!.priority;
      _tags = widget.note!.tags ?? [];
      _color = widget.note!.color;
    } else {
      // Set default color if creating a new note
      _color = Colors.white.toHexString();
    }
  }

  void _saveNote(BuildContext context) {
    final title = _titleController.text.trim();
    final content = _contentController.text.trim();
    if (title.isNotEmpty && content.isNotEmpty) {
      final now = DateTime.now();
      final newNote = Note(
        id: widget.note?.id,
        title: title,
        content: content,
        priority: _priority,
        createdAt: widget.note?.createdAt ?? now,
        modifiedAt: now,
        tags: _tags.isNotEmpty ? _tags : null,
        color: _color,
      );
      Navigator.pop(context, newNote);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Tiêu đề và nội dung không được để trống.')),
      );
    }
  }

  void _addTag() {
    final tag = _tagController.text.trim();
    if (tag.isNotEmpty && !_tags.contains(tag)) {
      setState(() {
        _tags.add(tag);
        _tagController.clear();
      });
    }
  }

  void _removeTag(String tag) {
    setState(() {
      _tags.remove(tag);
    });
  }

  void _showColorPicker() {
    Color currentColor = _getColorFromHex(_color ?? Colors.white.toHexString()) ?? Colors.white;
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Chọn màu sắc'),
          content: SingleChildScrollView(
            child: ColorPicker(
              pickerColor: currentColor,
              onColorChanged: (Color color) {
                setState(() {
                  _color = color.toHexString();
                });
              },
              pickerAreaHeightPercent: 0.8,
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Chọn'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Color? _getColorFromHex(String hexColor) {
    final hex = hexColor.replaceAll('#', '');
    if (hex.length == 6) {
      return Color(int.parse('FF$hex', radix: 16));
    } else if (hex.length == 8) {
      return Color(int.parse(hex, radix: 16));
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.note == null ? 'Thêm ghi chú' : 'Chỉnh sửa ghi chú'),
        actions: [
          IconButton(
            icon: Icon(Icons.save),
            onPressed: () => _saveNote(context),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(
                labelText: 'Tiêu đề',
                border: OutlineInputBorder(),
                errorText: _titleController.text.trim().isEmpty ? 'Tiêu đề không được để trống' : null,
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: _contentController,
              maxLines: 5,
              decoration: InputDecoration(
                labelText: 'Nội dung',
                border: OutlineInputBorder(),
                errorText: _contentController.text.trim().isEmpty ? 'Nội dung không được để trống' : null,
              ),
            ),
            SizedBox(height: 16.0),
            Text('Mức độ ưu tiên:', style: TextStyle(fontWeight: FontWeight.bold)),
            Row(
              children: [
                Radio<int>(
                  value: 1,
                  groupValue: _priority,
                  onChanged: (value) {
                    setState(() {
                      _priority = value!;
                    });
                  },
                ),
                Text('Thấp'),
                SizedBox(width: 16.0),
                Radio<int>(
                  value: 2,
                  groupValue: _priority,
                  onChanged: (value) {
                    setState(() {
                      _priority = value!;
                    });
                  },
                ),
                Text('Trung bình'),
                SizedBox(width: 16.0),
                Radio<int>(
                  value: 3,
                  groupValue: _priority,
                  onChanged: (value) {
                    setState(() {
                      _priority = value!;
                    });
                  },
                ),
                Text('Cao'),
              ],
            ),
            SizedBox(height: 16.0),
            Text('Nhãn (Tags):', style: TextStyle(fontWeight: FontWeight.bold)),
            Wrap(
              spacing: 8.0,
              children: _tags.map((tag) => Chip(
                label: Text(tag),
                onDeleted: () => _removeTag(tag),
              ))
                  .toList(),
            ),
            TextField(
              controller: _tagController,
              decoration: InputDecoration(
                labelText: 'Thêm nhãn',
                border: OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(Icons.add),
                  onPressed: _addTag,
                ),
              ),
              onSubmitted: (_) => _addTag(),
            ),
            SizedBox(height: 16.0),
            Text('Màu sắc:', style: TextStyle(fontWeight: FontWeight.bold)),
            InkWell(
              onTap: _showColorPicker,
              child: Container(
                margin: EdgeInsets.only(top: 8.0),
                width: 50.0,
                height: 50.0,
                decoration: BoxDecoration(
                  color: _getColorFromHex(_color ?? Colors.white.toHexString()),
                  border: Border.all(color: Colors.grey.shade300),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

ColorPicker({required Color pickerColor, required Null Function(Color color) onColorChanged, required double pickerAreaHeightPercent}) {
}

extension ColorExtension on Color {
  String toHexString() {
    return '#${value.toRadixString(16).substring(2).padLeft(6, '0').toUpperCase()}';
  }
}