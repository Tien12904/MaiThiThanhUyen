import "package:app_02/noteApp/view/NoteFormScreen.dart";
import "package:app_02/noteApp/view/NoteItem.dart";
import "../db/NoteDatabaseHelper.dart";
import "package:app_02/noteApp/model/Note.dart";
import "package:flutter/material.dart";


class NoteListScreen extends StatefulWidget {
  @override
  _NoteListScreenState createState() => _NoteListScreenState();
}

class _NoteListScreenState extends State<NoteListScreen> {
  final dbHelper = NoteDatabaseHelper.instance;
  List<Note> _notes = [];
  bool _isGridView = false;
  String _searchQuery = '';
  int? _filterPriority;
  String _sortOption = 'priority'; // Default sort by priority

  @override
  void initState() {
    super.initState();
    _loadNotes();
  }

  _loadNotes() async {
    List<Note> notes = await dbHelper.getAllNotes();
    if (_filterPriority != null) {
      notes = notes.where((note) => note.priority == _filterPriority).toList();
    }
    if (_searchQuery.isNotEmpty) {
      notes = await dbHelper.searchNotes(_searchQuery);
    }
    _sortNotes(notes, _sortOption);
    setState(() {
      _notes = notes;
    });
  }

  void _sortNotes(List<Note> notes, String sortBy) {
    setState(() {
      _sortOption = sortBy;
      if (sortBy == 'priority') {
        notes.sort((a, b) => b.priority.compareTo(a.priority));
      } else if (sortBy == 'created_at') {
        notes.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      } else if (sortBy == 'modified_at') {
        notes.sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
      }
    });
  }

  _addNote(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NoteListScreen()),
    );
    if (result != null && result is Note) {
      await dbHelper.insertNote(result);
      _loadNotes();
    }
  }

  _editNote(BuildContext context, Note note) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NoteForm(note: note)),
    );
    if (result != null && result is Note) {
      await dbHelper.updateNote(result);
      _loadNotes();
    }
  }

  _deleteNote(int id) async {
    await dbHelper.deleteNote(id);
    _loadNotes();
  }

  _showDeleteConfirmationDialog(BuildContext context, Note note) async {
    return showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Xác nhận xóa'),
          content: Text('Bạn có chắc chắn muốn xóa ghi chú "${note.title}"?'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Không'),
            ),
            TextButton(
              onPressed: () {
                _deleteNote(note.id!);
                Navigator.of(context).pop(true);
              },
              child: const Text('Có', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  _viewNoteDetail(BuildContext context, Note note) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NoteListScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ghi chú của bạn'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _loadNotes,
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'priority_low') {
                setState(() {
                  _filterPriority = 1;
                  _loadNotes();
                });
              } else if (value == 'priority_medium') {
                setState(() {
                  _filterPriority = 2;
                  _loadNotes();
                });
              } else if (value == 'priority_high') {
                setState(() {
                  _filterPriority = 3;
                  _loadNotes();
                });
              } else if (value == 'all') {
                setState(() {
                  _filterPriority = null;
                  _loadNotes();
                });
              }
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                value: 'all',
                child: Text('Tất cả ưu tiên'),
              ),
              const PopupMenuItem<String>(
                value: 'priority_low',
                child: Text('Ưu tiên thấp'),
              ),
              const PopupMenuItem<String>(
                value: 'priority_medium',
                child: Text('Ưu tiên trung bình'),
              ),
              const PopupMenuItem<String>(
                value: 'priority_high',
                child: Text('Ưu tiên cao'),
              ),
            ],
          ),
          IconButton(
            icon: Icon(_isGridView ? Icons.list : Icons.grid_view),
            onPressed: () {
              setState(() {
                _isGridView = !_isGridView;
              });
            },
          ),
        ],
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(60.0),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                  _loadNotes();
                });
              },
              decoration: InputDecoration(
                hintText: 'Tìm kiếm ghi chú...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.0)),
              ),
            ),
          ),
        ),
      ),
      body: _notes.isEmpty
          ? Center(child: Text('Không có ghi chú nào.'))
          : _isGridView
          ? GridView.builder(
        padding: const EdgeInsets.all(8.0),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.8,
        ),
        itemCount: _notes.length,
        itemBuilder: (context, index) {
          final note = _notes[index];
          return NoteItem(
            note: note,
            onTap: () => _viewNoteDetail(context, note),
            onEdit: () => _editNote(context, note),
            onDelete: () => _showDeleteConfirmationDialog(context, note),
          );
        },
      )
          : ListView.builder(
        padding: const EdgeInsets.all(8.0),
        itemCount: _notes.length,
        itemBuilder: (context, index) {
          final note = _notes[index];
          return NoteItem(
            note: note,
            onTap: () => _viewNoteDetail(context, note),
            onEdit: () => _editNote(context, note),
            onDelete: () => _showDeleteConfirmationDialog(context, note),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addNote(context),
        child: Icon(Icons.add),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _sortOption == 'priority'
            ? 0
            : _sortOption == 'created_at'
            ? 1
            : 2,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.sort), label: 'Ưu tiên'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: 'Ngày tạo'),
          BottomNavigationBarItem(icon: Icon(Icons.timer), label: 'Ngày sửa'),
        ],
        onTap: (index) {
          if (index == 0) {
            _sortNotes(_notes, 'priority');
          } else if (index == 1) {
            _sortNotes(_notes, 'created_at');
          } else if (index == 2) {
            _sortNotes(_notes, 'modified_at');
          }
        },
      ),
    );
  }
}